import PasswordWidget from "@/components/PasswordWidget"
export default function ChangePassword() {
    return (
        <main>
            <PasswordWidget/>
        </main>
    )
}
