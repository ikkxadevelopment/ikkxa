"use client"
const DefaultComponent = () => {

  return (
    <section className="">
      <div className="container">
       No comppnent 
      </div>
    </section >

  );
};

export default DefaultComponent;