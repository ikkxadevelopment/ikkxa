
import Products from "@/widgets/Products";

export default async function ProductsPage() {
    return (
        <main className="min-h-screen pt-32">
            <Products />
        </main>
    );
}

