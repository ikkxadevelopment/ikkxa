// import { useRouter } from 'next/router';


// export const checkLocale = (url) => {
//   const router = useRouter();

//   if (!router.isReady) return null;

//   const { locale } = router;
//   if(!url) return;
//   const localizedUrl = `/${locale}/${url}`;
//   return localizedUrl;
// };
